// app.js v22 — Trailwatcher by Surya Prakash Kasarla
// Clean v15 base + org picker + day modal + domain deduplication

const CACHE_KEY    = 'trailwatcher_v15';
const LOCK_KEY     = 'trailwatcher_lock_v1';
const LOCK_IDLE_MS = 10 * 60 * 1000;
const REMOVED_ORGS_KEY = 'trailwatcher_removed_orgs';
const NICKNAMES_KEY    = 'trailwatcher_nicknames';
const CUSTOM_ORGS_KEY  = 'trailwatcher_custom_orgs';
let orgNicknames = {};   // { instanceUrl: customName }
let customOrgs   = [];   // manually added org instanceUrls

async function loadNicknames() {
  const [n, c] = await Promise.all([
    new Promise(r => chrome.storage.local.get([NICKNAMES_KEY], d => r(d[NICKNAMES_KEY] || {}))),
    new Promise(r => chrome.storage.local.get([CUSTOM_ORGS_KEY], d => r(d[CUSTOM_ORGS_KEY] || [])))
  ]);
  orgNicknames = n;
  customOrgs   = c;
}
async function saveNickname(instanceUrl, name) {
  if (name) orgNicknames[instanceUrl] = name;
  else delete orgNicknames[instanceUrl];
  await new Promise(r => chrome.storage.local.set({ [NICKNAMES_KEY]: orgNicknames }, r));
}
async function saveCustomOrgs() {
  await new Promise(r => chrome.storage.local.set({ [CUSTOM_ORGS_KEY]: customOrgs }, r));
}
function displayName(org) {
  return orgNicknames[org.instanceUrl] || org.label;
}
let removedOrgs = new Set(); // instanceUrls the user has dismissed

async function loadRemovedOrgs() {
  const stored = await new Promise(r => chrome.storage.local.get([REMOVED_ORGS_KEY], d => r(d[REMOVED_ORGS_KEY] || [])));
  removedOrgs = new Set(stored);
}
async function saveRemovedOrgs() {
  await new Promise(r => chrome.storage.local.set({ [REMOVED_ORGS_KEY]: [...removedOrgs] }, r));
}

 // keep same key — reuses existing cache
const SF_API_VER   = 'v59.0';
const CACHE_TTLS   = { 1:2*3600000, 3:4*3600000, 7:8*3600000, 15:12*3600000, 30:24*3600000, 90:48*3600000, 180:72*3600000, 0:5*60000 };

let allRecords=[], filteredRecords=[];
let sortCol='CreatedDate', sortAsc=false;
let sessionInfo=null, sfTabId=null;
let currentFromDate=null, currentToDate=null, activeDays=7;
let searchQuery='';
let hiddenCols = new Set();   // column keys hidden by user
let wrapText   = false;       // wrap long cell text
const COL_PREFS_KEY = 'trailwatcher_col_prefs';

async function loadColPrefs() {
  const d = await new Promise(r => chrome.storage.local.get([COL_PREFS_KEY], x => r(x[COL_PREFS_KEY]||{})));
  hiddenCols = new Set(d.hidden || []);
  wrapText   = !!d.wrap;
}
async function saveColPrefs() {
  await new Promise(r => chrome.storage.local.set({ [COL_PREFS_KEY]: { hidden:[...hiddenCols], wrap:wrapText } }, r));
}
let detectedOrgs=[];        // [{instanceUrl, label, type, tab, hasCached}]
let pendingOrg=null;        // org selected in picker, awaiting day choice
let selectedDays=7;         // chosen in modal

const $=id=>document.getElementById(id);

// ═══════════════════════════════════════════════════════════════════════════
// DOMAIN NORMALISATION
// example--fullcopy.sandbox.lightning.force.com
// example--fullcopy.sandbox.my.salesforce-setup.com -> example--fullcopy.sandbox.my.salesforce.com
// example--fullcopy.sandbox.my.salesforce.com
// ═══════════════════════════════════════════════════════════════════════════
function toInstanceUrl(url) {
  if (!url) return null;
  const host = url.replace(/^https?:\/\//,'').split('/')[0].toLowerCase();

  // sandbox.lightning.force.com → sandbox.my.salesforce.com
  if (host.match(/\.sandbox\.lightning\.force\.com$/))
    return 'https://'+host.replace('.sandbox.lightning.force.com','.sandbox.my.salesforce.com');

  // sandbox.my.salesforce-setup.com → sandbox.my.salesforce.com
  if (host.match(/\.sandbox\.my\.salesforce-setup\.com$/))
    return 'https://'+host.replace('.sandbox.my.salesforce-setup.com','.sandbox.my.salesforce.com');

  // sandbox.lightning.salesforce-setup.com → sandbox.my.salesforce.com
  if (host.match(/\.sandbox\.lightning\.salesforce-setup\.com$/))
    return 'https://'+host.replace('.sandbox.lightning.salesforce-setup.com','.sandbox.my.salesforce.com');

  // lightning.force.com → my.salesforce.com
  if (host.match(/\.lightning\.force\.com$/))
    return 'https://'+host.replace('.lightning.force.com','.my.salesforce.com');

  // lightning.salesforce-setup.com → my.salesforce.com
  if (host.match(/\.lightning\.salesforce-setup\.com$/))
    return 'https://'+host.replace('.lightning.salesforce-setup.com','.my.salesforce.com');

  // salesforce-setup.com → my.salesforce.com (fallback)
  if (host.match(/\.salesforce-setup\.com$/))
    return 'https://'+host.replace(/\.salesforce-setup\.com$/,'.my.salesforce.com');

  // already on my.salesforce.com or similar
  if (host.match(/\.salesforce\.com$/)) return 'https://'+host;

  return 'https://'+host;
}

function orgLabel(instanceUrl) {
  return instanceUrl
    .replace('https://','')
    .replace('.my.salesforce.com','')
    .replace('.sandbox.my.salesforce.com',' (sandbox)');
}

function orgType(instanceUrl) {
  if (instanceUrl.includes('.sandbox.')) return 'sandbox';
  if (instanceUrl.includes('.scratch.'))  return 'scratch';
  return 'production';
}



// ═══════════════════════════════════════════════════════════════════════════
// LOCAL APP LOCK — prevents casual use of an already-open browser profile
// ═══════════════════════════════════════════════════════════════════════════
let lockRecord = null;
let lockTimer = null;
let lockMode = 'unlock';

function b64(bytes){ return btoa(String.fromCharCode.apply(null, Array.from(bytes))); }
function unb64(str){ return Uint8Array.from(atob(str), c => c.charCodeAt(0)); }
async function sha256(text){
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return b64(new Uint8Array(buf));
}
async function hashPin(pin, saltB64){ return sha256(saltB64 + ':' + pin); }
function newSalt(){ const a = new Uint8Array(16); crypto.getRandomValues(a); return b64(a); }
function getLockRecord(){ return new Promise(r => chrome.storage.local.get([LOCK_KEY], d => r(d[LOCK_KEY] || null))); }
function setLockRecord(v){ return new Promise(r => chrome.storage.local.set({ [LOCK_KEY]: v }, r)); }
function removeLockRecord(){ return new Promise(r => chrome.storage.local.remove([LOCK_KEY], r)); }
function setLockedUI(locked){
  const ov = $('lockOverlay');
  if (ov) ov.style.display = locked ? 'flex' : 'none';
  const btn = $('lockNowBtn');
  if (btn) btn.style.display = locked ? 'none' : '';
}
async function clearAllAuditCache(){
  await new Promise(r => chrome.storage.local.remove([CACHE_KEY], r));
  allRecords = [];
  filteredRecords = [];
  sessionInfo = null;
}
function configureLockUI(setup){
  lockMode = setup ? 'setup' : 'unlock';
  $('lockTitle').textContent = setup ? 'Create Trailwatcher PIN' : 'Unlock Trailwatcher';
  $('lockSub').textContent = setup
    ? 'Create a local PIN. Trailwatcher will require it before reading Salesforce sessions or cached audit data.'
    : 'Enter your local Trailwatcher PIN before this extension can read your Salesforce session or show cached audit data.';
  $('lockSetupFields').style.display = setup ? '' : 'none';
  $('lockUnlockFields').style.display = setup ? 'none' : '';
  $('lockSubmitBtn').textContent = setup ? 'Create PIN' : 'Unlock';
  $('lockMsg').textContent = '';
  setTimeout(() => (setup ? $('lockPinCreate') : $('lockPin'))?.focus(), 50);
}
async function secureStartup(){
  lockRecord = await getLockRecord();
  configureLockUI(!lockRecord);
  setLockedUI(true);
}
async function submitLock(){
  $('lockMsg').textContent = '';
  try {
    if (lockMode === 'setup') {
      const p1 = $('lockPinCreate').value || '';
      const p2 = $('lockPinConfirm').value || '';
      if (p1.length < 6) { $('lockMsg').textContent = 'Use at least 6 characters.'; return; }
      if (p1 !== p2) { $('lockMsg').textContent = 'PIN confirmation does not match.'; return; }
      const salt = newSalt();
      lockRecord = { salt, hash: await hashPin(p1, salt), createdAt: Date.now() };
      await setLockRecord(lockRecord);
    } else {
      const pin = $('lockPin').value || '';
      if (!lockRecord || await hashPin(pin, lockRecord.salt) !== lockRecord.hash) {
        $('lockMsg').textContent = 'Incorrect PIN.';
        return;
      }
    }
    $('lockPin').value = '';
    $('lockPinCreate').value = '';
    $('lockPinConfirm').value = '';
    setLockedUI(false);
    armIdleLock();
    await init();
  } catch(e) {
    $('lockMsg').textContent = 'Lock error: ' + (e.message || String(e));
  }
}
function armIdleLock(){
  clearTimeout(lockTimer);
  lockTimer = setTimeout(lockNow, LOCK_IDLE_MS);
}
async function lockNow(){
  clearTimeout(lockTimer);
  await clearAllAuditCache();
  setLockedUI(true);
  configureLockUI(false);
  showState('loading');
  setMsg('Trailwatcher locked.');
  setSub('Unlock to scan Salesforce tabs.');
}
['click','keydown','mousemove','scroll'].forEach(evt => document.addEventListener(evt, () => {
  if ($('lockOverlay')?.style.display !== 'flex') armIdleLock();
}, { passive:true }));

// ═══════════════════════════════════════════════════════════════════════════
// INIT — scan tabs, deduplicate orgs, show picker
// ═══════════════════════════════════════════════════════════════════════════
secureStartup();

async function init() {
  await scanAndShowOrgs(false);
}

async function scanAndShowOrgs(ignoreRemoved) {
  showState('loading');
  setMsg(ignoreRemoved ? 'Rescanning all open tabs…' : 'Scanning for Salesforce tabs…');
  setSub('');

  try {
    if (!ignoreRemoved) await loadRemovedOrgs();
    await loadNicknames();
    await loadColPrefs();

    const results = await Promise.all([
      queryTabs('*://*.salesforce.com/*'),
      queryTabs('*://*.lightning.force.com/*'),
      queryTabs('*://*.force.com/*'),
      queryTabs('*://*.salesforce-setup.com/*'),
      queryTabs('*://*.my.salesforce.com/*'),
      queryTabs('*://*.sandbox.my.salesforce.com/*'),
    ]);

    // Step 1: dedupe by tab ID (same tab can appear in multiple query results)
    const tabsById = {};
    results.flat().forEach(t => { if (t.id && !tabsById[t.id]) tabsById[t.id] = t; });

    // Step 2: dedupe by canonical instanceUrl (different tabs, same org)
    const seen = {};
    Object.values(tabsById).forEach(t => {
      const inst = toInstanceUrl(t.url);
      if (!inst) return;
      if (inst.startsWith('chrome-extension')) return; // skip our own tab
      if (!seen[inst]) seen[inst] = { instanceUrl:inst, tab:t, label:orgLabel(inst), type:orgType(inst) };
    });

    // Merge in any manually added orgs not already found in tabs
    customOrgs.forEach(instUrl => {
      if (!seen[instUrl]) {
        seen[instUrl] = { instanceUrl:instUrl, tab:null, label:orgLabel(instUrl), type:orgType(instUrl), isCustom:true };
      }
    });

    // Always show ALL detected orgs in picker — removed ones shown greyed with "Add back"
    const allOrgs = Object.values(seen);
    detectedOrgs = allOrgs; // keep full list for picker

    if (detectedOrgs.length === 0) { showState('noSession'); return; }

    await markCachedOrgs(detectedOrgs);

    // Active (non-removed) orgs
    const activeOrgs = detectedOrgs.filter(o => !removedOrgs.has(o.instanceUrl));

    if (ignoreRemoved) {
      // Rescan — show everything so user can restore hidden orgs
      showOrgPicker(detectedOrgs, true);
    } else if (activeOrgs.length === 0) {
      // All orgs hidden — show picker with reveal option
      showOrgPicker(detectedOrgs, false);
    } else if (activeOrgs.length === 1) {
      // Only 1 active org — skip picker, go straight to day modal
      openDayModal(activeOrgs[0]);
    } else {
      // Multiple active orgs — show only active ones
      showOrgPicker(detectedOrgs, false);
    }

  } catch(e) { showError('Scan failed: ' + (e.message || String(e))); }
}

// ═══════════════════════════════════════════════════════════════════════════
// ORG PICKER
// ═══════════════════════════════════════════════════════════════════════════
async function markCachedOrgs(orgs) {
  const stored = await new Promise(r=>chrome.storage.local.get([CACHE_KEY],d=>r(d[CACHE_KEY]||{})));
  orgs.forEach(org=>{
    const keys = Object.keys(stored).filter(k=>k.startsWith(org.instanceUrl+'||'));
    org.hasCached = keys.length > 0;
    if (keys.length) {
      const newest = Math.max(...keys.map(k=>stored[k].timestamp||0));
      const age = Date.now()-newest;
      org.cacheAge = age < 60000 ? 'just now'
        : age < 3600000 ? Math.round(age/60000)+'m ago'
        : Math.round(age/3600000)+'h ago';
    }
  });
}

function showOrgPicker(orgs, showHidden) {
  showState('orgPicker');

  // Declare visibleOrgs first — used throughout this function
  const visibleOrgs = showHidden ? orgs : orgs.filter(o => !removedOrgs.has(o.instanceUrl));
  const totalCount  = orgs.length;
  const activeCount = visibleOrgs.length;
  const hiddenCount = totalCount - activeCount;

  const sub = $('orgPickerSub');
  if (sub) {
    if (activeCount === 0) sub.textContent = 'All orgs are hidden. Click ⟳ Rescan to manage your org list.';
    else sub.textContent = `Found ${totalCount} Salesforce org${totalCount!==1?'s':''} in your open tabs`;
  }
  const countEl = $('pickerCount');
  if (countEl) countEl.textContent = hiddenCount > 0 ? `${activeCount} active · ${hiddenCount} hidden` : `${activeCount} active`;

  const cards = $('orgCards');
  cards.innerHTML = '';

  // hiddenCount already computed above
  const hiddenCount2 = hiddenCount;

  // Show "reveal hidden" hint if there are hidden orgs
  if (!showHidden && hiddenCount2 > 0) {
    const hint = document.createElement('div');
    hint.style.cssText = 'width:100%;text-align:center;margin-bottom:8px;';
    hint.innerHTML = '<span style="font-size:12px;color:#aaa;cursor:pointer;border-bottom:1px dashed #ccc;padding-bottom:1px" id="showHiddenHint">'+hiddenCount2+' hidden org'+(hiddenCount2>1?'s':'')+' — click Rescan to manage</span>';
    cards.appendChild(hint);
  }

  visibleOrgs.forEach(org => {
    const isRemoved = removedOrgs.has(org.instanceUrl);
    const name = displayName(org);
    const icon = org.type==='sandbox' ? '🏖️' : org.type==='scratch' ? '🔬' : '🏢';

    const card = document.createElement('div');
    card.className = 'org-card' + (isRemoved ? ' removed' : ' clickable');

    card.innerHTML = `
      <button class="card-action-btn ${isRemoved?'card-add-btn':'card-remove-btn'}"
              title="${isRemoved?'Restore':'Hide'}">${isRemoved?'+':'✕'}</button>
      <div class="org-card-icon">${icon}</div>
      <div class="org-card-name-wrap">
        <span class="org-card-name-display" title="Click to rename">${esc(name)}</span>
      </div>
      <div class="org-card-url">${esc(org.instanceUrl.replace('https://',''))}</div>
      <span class="org-card-type ${org.type}">${org.type}${org.isCustom?' · manual':''}</span>
      ${isRemoved
        ? '<div class="org-card-removed-label">Hidden — click + to restore</div>'
        : org.hasCached
          ? `<div class="org-card-cached">📦 Cached (${org.cacheAge})</div>`
          : '<div style="font-size:11px;color:#aaa;margin-top:4px">No cache yet</div>'
      }
    `;

    // ── Rename: click on name label → turns into input ──
    const nameDisplay = card.querySelector('.org-card-name-display');
    nameDisplay.addEventListener('click', e => {
      e.stopPropagation();
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'org-card-name-input';
      input.value = orgNicknames[org.instanceUrl] || org.label;
      nameDisplay.replaceWith(input);
      input.focus(); input.select();
      const commit = async () => {
        const val = input.value.trim();
        await saveNickname(org.instanceUrl, val || null);
        showOrgPicker(detectedOrgs);
      };
      input.addEventListener('blur', commit);
      input.addEventListener('keydown', e2 => {
        if (e2.key==='Enter') { e2.preventDefault(); input.blur(); }
        if (e2.key==='Escape') { input.removeEventListener('blur', commit); showOrgPicker(detectedOrgs); }
      });
    });

    // ── Toggle remove/restore ──
    const actionBtn = card.querySelector('.card-action-btn');
    actionBtn.addEventListener('click', async e => {
      e.stopPropagation();
      e.preventDefault();
      if (isRemoved) {
        removedOrgs.delete(org.instanceUrl);
      } else {
        removedOrgs.add(org.instanceUrl);
      }
      await saveRemovedOrgs();
      showOrgPicker(detectedOrgs);
    });

    // ── Open day modal on card click (not on buttons) ──
    if (!isRemoved) {
      card.addEventListener('click', e => {
        if (e.target.closest('.card-action-btn') || e.target.closest('.org-card-name-input')) return;
        openDayModal(org);
      });
    }

    cards.appendChild(card);
  });

  // ── Wire Add Org button ──
  const addBtn = $('addOrgBtn');
  const addInput = $('addOrgInput');
  if (addBtn && addInput) {
    addBtn.onclick = async () => {
      const raw = addInput.value.trim();
      if (!raw) return;
      const inst = toInstanceUrl(raw.startsWith('http') ? raw : 'https://'+raw);
      if (!inst) { addInput.style.borderColor='#c62828'; return; }
      addInput.style.borderColor='';
      if (!customOrgs.includes(inst)) { customOrgs.push(inst); await saveCustomOrgs(); }
      // Remove from removed if was there
      removedOrgs.delete(inst);
      await saveRemovedOrgs();
      // Add to detectedOrgs if not present
      if (!detectedOrgs.find(o=>o.instanceUrl===inst)) {
        detectedOrgs.push({ instanceUrl:inst, tab:null, label:orgLabel(inst), type:orgType(inst), isCustom:true });
      }
      await markCachedOrgs(detectedOrgs);
      addInput.value = '';
      showOrgPicker(detectedOrgs);
    };
    addInput.onkeydown = e => { if (e.key==='Enter') addBtn.onclick(); };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// DAY PICKER MODAL
// ═══════════════════════════════════════════════════════════════════════════
function openDayModal(org) {
  pendingOrg = org;
  selectedDays = 7;

  // Update modal label
  $('modalOrgName').textContent = `Pulling logs for: ${org.label}`;
  if (org.hasCached) {
    $('modalOrgName').textContent += ` · 📦 cache available (${org.cacheAge})`;
  }

  // Reset selection
  document.querySelectorAll('.day-opt').forEach(o=>{
    o.classList.toggle('selected', +o.dataset.days===7);
  });

  $('modalOverlay').classList.add('open');
}

document.querySelectorAll('.day-opt').forEach(opt=>{
  opt.addEventListener('click', ()=>{
    document.querySelectorAll('.day-opt').forEach(o=>o.classList.remove('selected'));
    opt.classList.add('selected');
    selectedDays = +opt.dataset.days;
  });
});

$('modalCancel').addEventListener('click', ()=>{
  $('modalOverlay').classList.remove('open');
  if (detectedOrgs.length > 1) showOrgPicker(detectedOrgs);
  // If only 1 org, keep modal closeable but go back to loader
});

$('modalLoad').addEventListener('click', async ()=>{
  $('modalOverlay').classList.remove('open');
  await loadOrgSession(pendingOrg, selectedDays===0 ? 7 : selectedDays);
});

// ═══════════════════════════════════════════════════════════════════════════
// SESSION + FETCH
// ═══════════════════════════════════════════════════════════════════════════
async function loadOrgSession(org, days) {
  showState('loading'); setMsg('Reading session…'); setSub(displayName(org));

  const instanceUrl = org.instanceUrl;

  if (org.tab) {
    sfTabId = org.tab.id;
    try { await withTimeout(chrome.scripting.executeScript({target:{tabId:sfTabId},files:['content.js']}), 2000); } catch(e){}
    await sleep(200);
    const urls = await msgTab(sfTabId, {type:'GET_URLS'});
    // instanceUrl already set above
    _ = urls; // unused but kept for session read below
  } else {
    // Custom org — find any SF tab to use for session cookie
    const anyTab = detectedOrgs.find(o => o.tab)?.tab;
    if (anyTab) {
      sfTabId = anyTab.id;
      try { await withTimeout(chrome.scripting.executeScript({target:{tabId:sfTabId},files:['content.js']}), 2000); } catch(e){}
      await sleep(200);
    }
  }
  if (false) { const instanceUrl = ''; }  // suppress unused warning

  sessionInfo = await msgBg({type:'GET_SESSION_BG', instanceUrl, lightningUrl: org.tab?.url||instanceUrl});

  if (!sessionInfo?.sessionId) {
    showError('Session cookie not found.\n\nMake sure you are logged in, then click Retry.\n\nOrg: '+instanceUrl);
    return;
  }

  sessionInfo.instanceUrl = instanceUrl; // ensure normalised

  // Update org pill in header
  $('orgName').textContent = displayName(org);
  $('orgSwitcher').style.display = '';
  buildOrgDropdown(org);

  // Set date range and fetch
  setActiveDays(days);
  await fetchAndShow(false);
}

// ═══════════════════════════════════════════════════════════════════════════
// ORG DROPDOWN (header switcher)
// ═══════════════════════════════════════════════════════════════════════════
function buildOrgDropdown(activeOrg) {
  const list = $('orgDropdownList');
  const chev = $('orgChevron');
  const countEl = $('orgCount');

  const visibleOrgs = detectedOrgs.filter(o => !removedOrgs.has(o.instanceUrl));
  // Always show dropdown
  chev.style.display = '';

  list.innerHTML = '';
  // Only show active (non-removed) orgs in dropdown
  const dropdownOrgs = detectedOrgs.filter(o => !removedOrgs.has(o.instanceUrl));
  dropdownOrgs.forEach(org => {
    const isActive = org.instanceUrl === activeOrg.instanceUrl;
    const el = document.createElement('div');
    el.className = 'org-option' + (isActive ? ' active-org' : '');
    el.innerHTML = `
      <div class="dot ${isActive ? '' : 'dim'}"></div>
      <div class="org-option-info">
        <div class="org-option-name">${esc(displayName(org))}</div>
        <div class="org-option-url">${esc(org.instanceUrl.replace('https://',''))}</div>
      </div>
      ${isActive ? '<span class="org-badge">Active</span>' : ''}
      <button class="org-option-remove" title="Remove from list">✕</button>
    `;
    // Switch org (click on the row, not the remove btn)
    if (!isActive) {
      el.addEventListener('click', e => {
        if (e.target.classList.contains('org-option-remove')) return;
        closeOrgDropdown();
        openDayModal(org);
      });
    }
    // Remove org
    el.querySelector('.org-option-remove').addEventListener('click', async e => {
      e.stopPropagation();
      await removeOrg(org, activeOrg);
    });
    list.appendChild(el);
  });

  if (countEl) { const v=dropdownOrgs.length; countEl.textContent = v + ' org' + (v!==1?'s':''); }
}

async function removeOrg(org, activeOrg) {
  removedOrgs.add(org.instanceUrl);
  await saveRemovedOrgs();

  if (org.instanceUrl === activeOrg?.instanceUrl) {
    closeOrgDropdown();
    $('orgSwitcher').style.display = 'none';
    showOrgPicker(detectedOrgs); // show picker with all orgs, removed one greyed
    return;
  }
  // Rebuild dropdown with updated removed state
  buildOrgDropdown(activeOrg);
}

// Rescan button — finds ALL open SF tabs fresh, ignores removed list
document.addEventListener('click', async e => {
  if (e.target && e.target.id === 'rescanOrgsBtn') {
    closeOrgDropdown();
    await scanAndShowOrgs(true); // true = ignore removedOrgs
  }
});

$('orgPill').addEventListener('click', ()=>{
  if ($('orgChevron').style.display==='none') return;
  const dd=$('orgDropdown'), chev=$('orgChevron');
  const opening=!dd.classList.contains('open');
  dd.classList.toggle('open',opening);
  chev.classList.toggle('open',opening);
});
document.addEventListener('click', e=>{
  const sw=$('orgSwitcher');
  if (sw&&!sw.contains(e.target)) closeOrgDropdown();
});
function closeOrgDropdown(){$('orgDropdown').classList.remove('open');$('orgChevron').classList.remove('open');}

// ═══════════════════════════════════════════════════════════════════════════
// CACHE
// ═══════════════════════════════════════════════════════════════════════════
function cacheKey(){
  return activeDays>0
    ? sessionInfo.instanceUrl+'||d:'+activeDays
    : sessionInfo.instanceUrl+'||'+ds(currentFromDate)+'||'+ds(currentToDate);
}
function ds(d){return d.toISOString().split('T')[0];}
function ttl(days){const d=days!==undefined?days:activeDays;return CACHE_TTLS[d]!==undefined?CACHE_TTLS[d]:CACHE_TTLS[0];}
function getCache(key,days){return new Promise(resolve=>{chrome.storage.local.get([CACHE_KEY],r=>{const s=r[CACHE_KEY]||{},e=s[key];if(!e||Date.now()-e.timestamp>ttl(days))return resolve(null);resolve(e);});});}
function setCache(key,records){return new Promise(resolve=>{chrome.storage.local.get([CACHE_KEY],r=>{const s=r[CACHE_KEY]||{};Object.keys(s).forEach(k=>{if(Date.now()-s[k].timestamp>5*86400000)delete s[k];});s[key]={records,timestamp:Date.now()};chrome.storage.local.set({[CACHE_KEY]:s},resolve);});});}
function delCache(key){return new Promise(resolve=>{chrome.storage.local.get([CACHE_KEY],r=>{const s=r[CACHE_KEY]||{};delete s[key];chrome.storage.local.set({[CACHE_KEY]:s},resolve);});});}

// ═══════════════════════════════════════════════════════════════════════════
// DATE RANGE
// ═══════════════════════════════════════════════════════════════════════════
function setActiveDays(days){
  activeDays=days;
  const to=new Date(); to.setHours(23,59,59,999);
  const from=new Date(); from.setDate(from.getDate()-days+1); from.setHours(0,0,0,0);
  currentFromDate=from; currentToDate=to;
  document.querySelectorAll('.range-btn').forEach(b=>b.classList.toggle('active',+b.dataset.days===days));
  $('customFrom').value=ds(from); $('customTo').value=ds(to);
}
function rangeLabel(){const p={1:'Today',3:'3 Days',7:'1 Week',15:'15 Days',30:'1 Month',90:'3 Months',180:'6 Months'};return p[activeDays]||(ds(currentFromDate)+' → '+ds(currentToDate));}

// ═══════════════════════════════════════════════════════════════════════════
// FETCH
// ═══════════════════════════════════════════════════════════════════════════
async function fetchAndShow(forceRefresh){
  showState('loading');
  const key=cacheKey();
  if(!forceRefresh){
    setMsg('Checking cache…'); setSub(rangeLabel());
    const cached=await getCache(key,activeDays);
    if(cached){allRecords=cached.records;renderAll(true,cached.timestamp);return;}
    setMsg('Fetching from Salesforce…'); setSub(rangeLabel());
  } else {setMsg('Force refreshing…');setSub(rangeLabel());}
  await fetchAPI(key);
}

async function fetchAPI(key){
  const{instanceUrl}=sessionInfo;
  const soql=
    'SELECT Id,Action,Section,CreatedDate,CreatedBy.Name,CreatedBy.Username,Display,DelegateUser '+
    'FROM SetupAuditTrail '+
    'WHERE CreatedDate >= '+currentFromDate.toISOString()+
    ' AND CreatedDate <= '+currentToDate.toISOString()+
    ' ORDER BY CreatedDate DESC LIMIT 50000';

  let records=[],nextUrl=instanceUrl+'/services/data/'+SF_API_VER+'/query/?q='+encodeURIComponent(soql);
  while(nextUrl){
    setMsg('Fetching…'); setSub(records.length.toLocaleString()+' records loaded');
    const json=await bgFetch(nextUrl);
    if(json.records) records=records.concat(json.records);
    nextUrl=json.nextRecordsUrl?instanceUrl+json.nextRecordsUrl:null;
  }
  await setCache(key,records);
  allRecords=records;
  renderAll(false,Date.now());
}

function renderAll(fromCache,ts){
  populateFilters();applyFilters();showState('data');
  $('dateRangeBar').style.display='';
  $('filtersBar').style.display='';
  $('colControls').style.display='';
  applyColPrefs();
  $('exportBtn').style.display='';$('refreshBtn').style.display='';
  const badge=$('cacheBadge');
  if(fromCache){
    const age=Date.now()-ts;
    const a=age<60000?'just now':age<3600000?Math.round(age/60000)+'m ago':Math.round(age/3600000)+'h ago';
    badge.textContent='📦 Cached '+a;badge.className='badge badge-cache';
  } else {badge.textContent='🟢 Live';badge.className='badge badge-live';}
  badge.style.display='';
  const ttlH=ttl(activeDays)>=3600000?Math.round(ttl(activeDays)/3600000)+'h':Math.round(ttl(activeDays)/60000)+'min';
  $('footerLeft').textContent=allRecords.length.toLocaleString()+' records · '+rangeLabel()+'   ·   Cache: '+ttlH+'   ·   ↻ to force-refresh';
}

// ═══════════════════════════════════════════════════════════════════════════
// FILTERS & TABLE
// ═══════════════════════════════════════════════════════════════════════════
function populateFilters(){
  const ss=$('sectionFilter'),us=$('userFilter');
  const secSet={},usrSet={},secs=[],usrs=[];
  allRecords.forEach(r=>{
    if(r.Section&&!secSet[r.Section]){secSet[r.Section]=1;secs.push(r.Section);}
    const n=r.CreatedBy?.Name;if(n&&!usrSet[n]){usrSet[n]=1;usrs.push(n);}
  });
  secs.sort();ss.innerHTML='<option value="">All Sections</option>';
  secs.forEach(s=>{const o=document.createElement('option');o.value=s;o.textContent=s;ss.appendChild(o);});
  usrs.sort();us.innerHTML='<option value="">All Users</option>';
  usrs.forEach(u=>{const o=document.createElement('option');o.value=u;o.textContent=u;us.appendChild(o);});
}
function applyFilters(){
  const q=searchQuery.toLowerCase().trim(),sec=$('sectionFilter').value,usr=$('userFilter').value;
  filteredRecords=allRecords.filter(r=>{
    if(sec&&r.Section!==sec)return false;
    if(usr&&r.CreatedBy?.Name!==usr)return false;
    if(q){const hay=[r.Action,r.Section,r.Display,r.CreatedBy?.Name,r.CreatedBy?.Username,r.DelegateUser].filter(Boolean).join(' ').toLowerCase();if(!hay.includes(q))return false;}
    return true;
  });
  $('clearSearch').classList.toggle('visible',searchQuery.length>0);
  sortAndRender();
}
function sortAndRender(){
  filteredRecords.sort((a,b)=>{
    let av=sortCol==='UserName'?(a.CreatedBy?.Name||''):(a[sortCol]||'');
    let bv=sortCol==='UserName'?(b.CreatedBy?.Name||''):(b[sortCol]||'');
    if(sortCol==='CreatedDate'){av=new Date(av);bv=new Date(bv);}
    if(av<bv)return sortAsc?-1:1;if(av>bv)return sortAsc?1:-1;return 0;
  });
  $('filterCount').textContent=filteredRecords.length.toLocaleString()+' of '+allRecords.length.toLocaleString();
  renderTable();
}
function highlight(text,q){if(!q)return esc(text);const re=new RegExp('('+esc(q).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','gi');return esc(text).replace(re,'<span class="highlight">$1</span>');}
function sectionTagClass(s){if(!s)return 'tag-default';const l=s.toLowerCase();if(l.includes('user'))return 'tag-users';if(l.includes('secur')||l.includes('auth')||l.includes('password'))return 'tag-security';if(l.includes('data')||l.includes('import')||l.includes('export'))return 'tag-data';if(l.includes('object')||l.includes('field')||l.includes('custom')||l.includes('flow'))return 'tag-custom';return 'tag-default';}
function renderTable(){
  const q=searchQuery.toLowerCase().trim();
  $('tableBody').innerHTML=filteredRecords.slice(0,5000).map(r=>{
    const date=new Date(r.CreatedDate).toLocaleString(undefined,{month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'});
    const uName=r.CreatedBy?.Name||'—',uLogin=r.CreatedBy?.Username||'';
    return `<tr>
      <td style="white-space:nowrap;font-size:12px;color:#555">${date}</td>
      <td>${r.Section?`<span class="section-tag ${sectionTagClass(r.Section)}">${highlight(r.Section,q)}</span>`:'—'}</td>
      <td class="truncate" title="${esc(r.Action||'')}">${highlight(r.Action||'—',q)}</td>
      <td><div style="font-weight:600">${highlight(uName,q)}</div>${uLogin?`<div style="color:#706e6b;font-size:11px">${highlight(uLogin,q)}</div>`:''}</td>
      <td class="truncate" title="${esc(r.Display||'')}">${highlight(r.Display||'—',q)}</td>
      <td style="font-size:12px;color:#555">${esc(r.DelegateUser||'—')}</td>
    </tr>`;
  }).join('');
  if(filteredRecords.length>5000)$('filterCount').textContent+=' (showing 5,000)';
}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

// ═══════════════════════════════════════════════════════════════════════════
// EVENTS
// ═══════════════════════════════════════════════════════════════════════════
document.querySelectorAll('.range-btn').forEach(btn=>{
  btn.addEventListener('click',async()=>{setActiveDays(+btn.dataset.days);await fetchAndShow(false);});
});
$('customGoBtn').addEventListener('click',async()=>{
  const fv=$('customFrom').value,tv=$('customTo').value;if(!fv||!tv)return;
  currentFromDate=new Date(fv+'T00:00:00');currentToDate=new Date(tv+'T23:59:59');activeDays=0;
  document.querySelectorAll('.range-btn').forEach(b=>b.classList.remove('active'));
  await fetchAndShow(false);
});
$('refreshBtn').addEventListener('click',async()=>{const key=cacheKey();await delCache(key);await fetchAPI(key);});
$('searchInput').addEventListener('input',e=>{searchQuery=e.target.value;applyFilters();});
$('clearSearch').addEventListener('click',()=>{$('searchInput').value='';searchQuery='';applyFilters();$('searchInput').focus();});
$('sectionFilter').addEventListener('change',applyFilters);
$('userFilter').addEventListener('change',applyFilters);
$('retryBtn').addEventListener('click',init);

// ─── Column toggles ────────────────────────────────────────────────────────
document.querySelectorAll('.col-toggle[data-col]').forEach(btn => {
  const col = btn.dataset.col;
  btn.addEventListener('click', async () => {
    if (hiddenCols.has(col)) hiddenCols.delete(col);
    else hiddenCols.add(col);
    await saveColPrefs();
    applyColPrefs();
  });
});

$('wrapToggle').addEventListener('click', async () => {
  wrapText = !wrapText;
  await saveColPrefs();
  applyColPrefs();
});

function applyColPrefs() {
  // Update toggle button states
  document.querySelectorAll('.col-toggle[data-col]').forEach(btn => {
    btn.classList.toggle('off', hiddenCols.has(btn.dataset.col));
  });
  const wt = $('wrapToggle');
  if (wt) wt.classList.toggle('off', !wrapText);

  // Column nth-child indices (1-based, Date = col 1)
  const colIndex = { Section:2, Action:3, User:4, Display:5, Delegate:6 };

  // Build CSS rule that hides entire columns (both th AND td) reliably
  let css = '';
  hiddenCols.forEach(col => {
    if (colIndex[col]) {
      const n = colIndex[col];
      css += `table th:nth-child(${n}), table td:nth-child(${n}) { display:none !important; }\n`;
    }
  });
  // Wrap text rule
  if (wrapText) css += 'table td { white-space:normal !important; word-break:break-word; }\n';

  const styleEl = document.getElementById('colHideStyle');
  if (styleEl) styleEl.textContent = css;

  renderTable();
}

// ─── Column resizing ────────────────────────────────────────────────────────
let resizeState = null;
document.addEventListener('mousedown', e => {
  const resizer = e.target.closest('.col-resizer');
  if (!resizer) return;
  const th = resizer.closest('th');
  if (!th) return;
  e.preventDefault();
  resizer.classList.add('dragging');
  resizeState = { th, startX: e.clientX, startW: th.offsetWidth };
});
document.addEventListener('mousemove', e => {
  if (!resizeState) return;
  const delta = e.clientX - resizeState.startX;
  const newW  = Math.max(60, resizeState.startW + delta);
  resizeState.th.style.width    = newW + 'px';
  resizeState.th.style.minWidth = newW + 'px';
});
document.addEventListener('mouseup', e => {
  if (!resizeState) return;
  document.querySelectorAll('.col-resizer').forEach(r => r.classList.remove('dragging'));
  resizeState = null;
});
$('lockSubmitBtn').addEventListener('click', submitLock);
$('lockPin').addEventListener('keydown', e => { if (e.key === 'Enter') submitLock(); });
$('lockPinCreate').addEventListener('keydown', e => { if (e.key === 'Enter') $('lockPinConfirm').focus(); });
$('lockPinConfirm').addEventListener('keydown', e => { if (e.key === 'Enter') submitLock(); });
$('lockNowBtn').addEventListener('click', lockNow);
$('lockResetBtn').addEventListener('click', async () => {
  if (!confirm('Reset the local Trailwatcher PIN and clear cached audit data on this browser profile?')) return;
  await clearAllAuditCache();
  await removeLockRecord();
  lockRecord = null;
  configureLockUI(true);
  setLockedUI(true);
});
$('pickerRescanBtn').addEventListener('click', () => scanAndShowOrgs(true));
$('retryBtn2').addEventListener('click',init);
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='f'){e.preventDefault();$('searchInput').focus();$('searchInput').select();}});
document.querySelectorAll('th[data-col]').forEach(th=>{
  th.addEventListener('click',()=>{
    const col=th.dataset.col;
    if(sortCol===col)sortAsc=!sortAsc;else{sortCol=col;sortAsc=true;}
    document.querySelectorAll('th[data-col]').forEach(t=>{t.classList.remove('sorted');t.querySelector('.sort-icon').textContent='';});
    th.classList.add('sorted');th.querySelector('.sort-icon').textContent=sortAsc?'↑':'↓';
    sortAndRender();
  });
});
$('exportBtn').addEventListener('click',()=>{
  const cols=['CreatedDate','Section','Action','User','Username','Display','DelegateUser'];
  const rows=filteredRecords.map(r=>[r.CreatedDate,r.Section||'',r.Action||'',r.CreatedBy?.Name||'',r.CreatedBy?.Username||'',r.Display||'',r.DelegateUser||''].map(v=>`"${String(v).replace(/"/g,'""')}"`).join(','));
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([[cols.join(','),...rows].join('\n')],{type:'text/csv'}));
  a.download=`trailwatcher_${ds(currentFromDate)}_${ds(currentToDate)}.csv`;
  a.click();
});

// ═══════════════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════════════
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
function withTimeout(p,ms,fb=null){return Promise.race([p,new Promise(r=>setTimeout(()=>r(fb),ms))]);}
function queryTabs(pattern){return withTimeout(new Promise(resolve=>{chrome.tabs.query({url:pattern},tabs=>{if(chrome.runtime.lastError)resolve([]);else resolve(tabs||[]);});}),2000,[]);}
function msgTab(tabId,payload){return withTimeout(new Promise(resolve=>{try{chrome.tabs.sendMessage(tabId,payload,resp=>{if(chrome.runtime.lastError)resolve(null);else resolve(resp);});}catch(e){resolve(null);}}),3000,null);}
function msgBg(payload){return withTimeout(new Promise((resolve,reject)=>{chrome.runtime.sendMessage(payload,result=>{if(chrome.runtime.lastError)reject(new Error(chrome.runtime.lastError.message));else resolve(result);});}),5000,null);}
async function bgFetch(url){
  const r=await msgBg({type:'BG_FETCH',url,sessionId:sessionInfo.sessionId});
  if(!r)throw new Error('No response from background worker');
  if(r.error)throw new Error(r.error);
  if(!r.ok){const d=r.data;let m='HTTP '+r.status;if(Array.isArray(d)&&d[0]?.message)m=d[0].errorCode+': '+d[0].message;else if(d?.message)m=d.message;else if(d?._raw)m=d._raw.slice(0,200);if(r.status===401)throw new Error('Session expired. Refresh your Salesforce tab then click Retry.');throw new Error(m);}
  return r.data;
}

// ═══════════════════════════════════════════════════════════════════════════
// STATE MANAGER
// ═══════════════════════════════════════════════════════════════════════════
function showState(s){
  $('stateLoading').style.display   = s==='loading'   ?'flex':'none';
  $('stateNoSession').style.display = s==='noSession' ?'flex':'none';
  $('stateError').style.display     = s==='error'     ?'flex':'none';
  $('stateOrgPicker').style.display = s==='orgPicker' ?'flex':'none';
  $('stateData').style.display      = s==='data'      ?'flex':'none';
  if(s!=='data'){$('dateRangeBar').style.display='none';$('filtersBar').style.display='none';}
}
function showError(m){$('errorMsg').textContent='⚠ '+m;showState('error');}
function setMsg(t){const e=$('loadingMsg');if(e)e.textContent=t;}
function setSub(t){const e=$('loadingSub');if(e)e.textContent=t;}
