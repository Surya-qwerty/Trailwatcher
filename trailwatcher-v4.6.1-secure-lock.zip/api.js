// api.js — Salesforce REST API helpers

const SF_API_VERSION = 'v59.0';
const CACHE_KEY = 'sf_audit_cache';
const CACHE_DURATION_MS = 15 * 60 * 1000; // 15 minutes

export async function fetchAuditTrail(sessionId, instanceUrl, forceRefresh = false) {
  // Check cache first
  if (!forceRefresh) {
    const cached = await getCache(instanceUrl);
    if (cached) return { data: cached, fromCache: true };
  }

  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
  const dateStr = sixMonthsAgo.toISOString().split('T')[0];

  // SOQL query for SetupAuditTrail
  const soql = encodeURIComponent(
    `SELECT Id, Action, Section, CreatedDate, CreatedBy.Name, CreatedBy.Username, Display, DelegateUser
     FROM SetupAuditTrail
     WHERE CreatedDate >= ${dateStr}T00:00:00Z
     ORDER BY CreatedDate DESC
     LIMIT 50000`
  );

  const url = `${instanceUrl}/services/data/${SF_API_VERSION}/query/?q=${soql}`;

  let allRecords = [];
  let nextUrl = url;

  while (nextUrl) {
    const response = await fetch(nextUrl, {
      headers: {
        'Authorization': `Bearer ${sessionId}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err[0]?.message || `HTTP ${response.status}`);
    }

    const json = await response.json();
    allRecords = allRecords.concat(json.records);

    // Handle pagination
    if (json.nextRecordsUrl) {
      nextUrl = `${instanceUrl}${json.nextRecordsUrl}`;
    } else {
      nextUrl = null;
    }
  }

  await setCache(instanceUrl, allRecords);
  return { data: allRecords, fromCache: false };
}

async function getCache(instanceUrl) {
  return new Promise(resolve => {
    chrome.storage.local.get([CACHE_KEY], result => {
      const cache = result[CACHE_KEY];
      if (!cache) return resolve(null);
      const entry = cache[instanceUrl];
      if (!entry) return resolve(null);
      if (Date.now() - entry.timestamp > CACHE_DURATION_MS) return resolve(null);
      resolve(entry.records);
    });
  });
}

async function setCache(instanceUrl, records) {
  return new Promise(resolve => {
    chrome.storage.local.get([CACHE_KEY], result => {
      const cache = result[CACHE_KEY] || {};
      cache[instanceUrl] = { records, timestamp: Date.now() };
      chrome.storage.local.set({ [CACHE_KEY]: cache }, resolve);
    });
  });
}

export async function clearCache(instanceUrl) {
  return new Promise(resolve => {
    chrome.storage.local.get([CACHE_KEY], result => {
      const cache = result[CACHE_KEY] || {};
      if (instanceUrl) delete cache[instanceUrl];
      else Object.keys(cache).forEach(k => delete cache[k]);
      chrome.storage.local.set({ [CACHE_KEY]: cache }, resolve);
    });
  });
}

export function getCacheAge(instanceUrl) {
  return new Promise(resolve => {
    chrome.storage.local.get([CACHE_KEY], result => {
      const cache = result[CACHE_KEY];
      if (!cache || !cache[instanceUrl]) return resolve(null);
      resolve(cache[instanceUrl].timestamp);
    });
  });
}
