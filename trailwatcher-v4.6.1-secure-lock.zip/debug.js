function log(msg, cls) {
  const el = document.createElement('pre');
  el.className = cls || '';
  el.textContent = msg;
  document.getElementById('out').appendChild(el);
}

async function runDiag() {
  document.getElementById('out').innerHTML = '';
  log('=== SF Audit Trail Diagnostics ===');

  // 1. Active tab
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  log('Active tab URL: ' + tab.url, 'warn');

  const isSF = tab.url && (tab.url.includes('.salesforce.com') || tab.url.includes('.lightning.force.com') || tab.url.includes('.force.com'));
  if (!isSF) { log('✗ NOT on a Salesforce page', 'err'); return; }
  log('✓ On Salesforce page', 'ok');

  // 2. Inject content script
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    log('✓ Content script injected', 'ok');
  } catch(e) {
    log('⚠ Injection warning (may already exist): ' + e.message, 'warn');
  }

  await new Promise(r => setTimeout(r, 400));

  // 3. Get session
  const session = await new Promise(resolve => {
    chrome.tabs.sendMessage(tab.id, { type: 'GET_SESSION' }, resp => {
      if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
      else resolve(resp);
    });
  });

  log('Session response: ' + JSON.stringify(session, null, 2), session && session.instanceUrl ? 'ok' : 'err');

  if (!session || !session.instanceUrl) {
    log('✗ No instanceUrl in session response', 'err'); return;
  }

  // 4. Test API call
  log('Testing API: ' + session.instanceUrl + '/services/data/');
  const apiTest = await new Promise(resolve => {
    chrome.tabs.sendMessage(tab.id, {
      type: 'FETCH_SF',
      url: session.instanceUrl + '/services/data/',
      sessionId: session.sessionId
    }, resp => {
      if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
      else resolve(resp);
    });
  });

  log('API test response (status=' + (apiTest && apiTest.status) + '): ' + JSON.stringify(apiTest && apiTest.data, null, 2).slice(0, 500),
    apiTest && apiTest.ok ? 'ok' : 'err');

  // 5. Test SOQL
  if (apiTest && apiTest.ok) {
    log('Testing SOQL query…', 'warn');
    const soql = 'SELECT Id,Action,Section,CreatedDate FROM SetupAuditTrail ORDER BY CreatedDate DESC LIMIT 3';
    const soqlUrl = session.instanceUrl + '/services/data/v59.0/query/?q=' + encodeURIComponent(soql);
    const soqlTest = await new Promise(resolve => {
      chrome.tabs.sendMessage(tab.id, { type: 'FETCH_SF', url: soqlUrl, sessionId: session.sessionId }, resp => {
        if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
        else resolve(resp);
      });
    });
    log('SOQL response (status=' + (soqlTest && soqlTest.status) + '): ' + JSON.stringify(soqlTest && soqlTest.data, null, 2).slice(0, 800),
      soqlTest && soqlTest.ok ? 'ok' : 'err');
  }

  log('=== Done ===');
}
