// popup.js v8 — stable cache keys, long TTLs, no unnecessary re-fetches

const CACHE_KEY = 'sf_audit_cache_v3';

// Cache TTLs per range — once loaded, stays until TTL expires
const CACHE_TTLS = {
  1:   30 * 60 * 1000,   // Today        → 30 min
  3:   60 * 60 * 1000,   // 3 days       → 1 hour
  7:    2 * 60 * 60 * 1000,  // 1 week   → 2 hours
  15:   4 * 60 * 60 * 1000,  // 15 days  → 4 hours
  30:   6 * 60 * 60 * 1000,  // 1 month  → 6 hours
  90:  12 * 60 * 60 * 1000,  // 3 months → 12 hours
  180: 24 * 60 * 60 * 1000,  // 6 months → 24 hours
  0:    5 * 60 * 1000    // custom range  → 5 min
};

const SF_API_VERSION = 'v59.0';

let allRecords = [];
let filteredRecords = [];
let sortCol = 'CreatedDate';
let sortAsc = false;
let sessionInfo = null;
let activeTabId = null;
let currentFromDate = null;
let currentToDate = null;
let activeDays = 180;

const $ = id => document.getElementById(id);

init();

async function init() {
  showState('loading');
  setMsg('Detecting Salesforce session…');
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    activeTabId = tab.id;

    const url = tab.url || '';
    const isSF = url.includes('.salesforce.com') || url.includes('.lightning.force.com') || url.includes('.force.com');
    if (!isSF) { showState('noSession'); return; }

    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }); } catch(e) {}
    await sleep(200);

    const urls = await msgTab(tab.id, { type: 'GET_URLS' });
    if (!urls || !urls.instanceUrl) { showState('noSession'); return; }

    setMsg('Reading session…');
    sessionInfo = await msgBg({ type: 'GET_SESSION_BG', instanceUrl: urls.instanceUrl, lightningUrl: urls.lightningUrl });

    if (!sessionInfo || !sessionInfo.sessionId) {
      showError('Could not read Salesforce session cookie.\nMake sure you are logged in and try again.\nURL: ' + (urls.instanceUrl || '?'));
      return;
    }

    $('orgName').textContent = sessionInfo.instanceUrl.replace('https://', '');

    // Check if we have ANY cached data to show immediately
    setMsg('Checking cache…');
    setActiveDays(180);
    await fetchAndShow();

  } catch(e) {
    showError('Init failed: ' + (e.message || String(e)));
  }
}

// ─── Stable cache key — date-only, no time component ─────────────────────
function makeCacheKey(days, fromDate, toDate) {
  // For preset ranges, key is org + days only (not exact dates)
  // This means reopening same day always hits cache
  if (days > 0) {
    return sessionInfo.instanceUrl + '|days:' + days;
  }
  // For custom, key is org + from + to (date only, no time)
  return sessionInfo.instanceUrl + '|' + toDateStr(fromDate) + '|' + toDateStr(toDate);
}

function toDateStr(d) { return d.toISOString().split('T')[0]; }

function rangeLabel() {
  const presets = {1:'Today',3:'3 Days',7:'1 Week',15:'15 Days',30:'1 Month',90:'3 Months',180:'6 Months'};
  return presets[activeDays] || (toDateStr(currentFromDate) + ' → ' + toDateStr(currentToDate));
}

// ─── Cache helpers ────────────────────────────────────────────────────────
function getTTL(days) {
  return CACHE_TTLS[days] || CACHE_TTLS[0];
}

function getCacheEntry(key, days) {
  return new Promise(function(resolve) {
    chrome.storage.local.get([CACHE_KEY], function(r) {
      const cache = r[CACHE_KEY] || {};
      const entry = cache[key];
      if (!entry) return resolve(null);
      const ttl = getTTL(days);
      const age = Date.now() - entry.timestamp;
      if (age > ttl) return resolve(null);
      resolve(entry);
    });
  });
}

function saveCacheEntry(key, records) {
  return new Promise(function(resolve) {
    chrome.storage.local.get([CACHE_KEY], function(r) {
      const cache = r[CACHE_KEY] || {};
      // Evict entries older than 25 hours
      Object.keys(cache).forEach(function(k) {
        if (Date.now() - cache[k].timestamp > 25 * 60 * 60 * 1000) delete cache[k];
      });
      cache[key] = { records: records, timestamp: Date.now() };
      chrome.storage.local.set({ [CACHE_KEY]: cache }, resolve);
    });
  });
}

function clearCacheEntry(key) {
  return new Promise(function(resolve) {
    chrome.storage.local.get([CACHE_KEY], function(r) {
      const cache = r[CACHE_KEY] || {};
      delete cache[key];
      chrome.storage.local.set({ [CACHE_KEY]: cache }, resolve);
    });
  });
}

// ─── Date range setup ─────────────────────────────────────────────────────
function setActiveDays(days) {
  activeDays = days;
  const to = new Date();
  const from = new Date();
  from.setDate(from.getDate() - days + 1);
  from.setHours(0, 0, 0, 0);
  to.setHours(23, 59, 59, 999);
  currentFromDate = from;
  currentToDate = to;

  document.querySelectorAll('.range-btn').forEach(function(b) {
    b.classList.toggle('active', parseInt(b.dataset.days) === days);
  });
  $('customFrom').value = toDateStr(from);
  $('customTo').value = toDateStr(to);
}

// ─── Fetch & show ─────────────────────────────────────────────────────────
async function fetchAndShow(forceRefresh) {
  showState('loading');
  const cacheKey = makeCacheKey(activeDays, currentFromDate, currentToDate);

  if (!forceRefresh) {
    setMsg('Checking cache…');
    const cached = await getCacheEntry(cacheKey, activeDays);
    if (cached) {
      allRecords = cached.records;
      showData(true, cached.timestamp, cacheKey);
      return;
    }
  }

  // Nothing cached — fetch from API
  await loadFromAPI(cacheKey);
}

async function loadFromAPI(cacheKey) {
  const instanceUrl = sessionInfo.instanceUrl;
  const fromStr = currentFromDate.toISOString();
  const toStr = currentToDate.toISOString();

  const soql =
    'SELECT Id,Action,Section,CreatedDate,CreatedBy.Name,CreatedBy.Username,Display,DelegateUser ' +
    'FROM SetupAuditTrail ' +
    'WHERE CreatedDate >= ' + fromStr + ' AND CreatedDate <= ' + toStr + ' ' +
    'ORDER BY CreatedDate DESC LIMIT 50000';

  let records = [];
  let nextUrl = instanceUrl + '/services/data/' + SF_API_VERSION + '/query/?q=' + encodeURIComponent(soql);

  while (nextUrl) {
    setMsg('Fetching… ' + records.length.toLocaleString() + ' records');
    const json = await bgFetch(nextUrl);
    if (json.records) records = records.concat(json.records);
    nextUrl = json.nextRecordsUrl ? instanceUrl + json.nextRecordsUrl : null;
  }

  await saveCacheEntry(cacheKey, records);
  allRecords = records;
  showData(false, Date.now(), cacheKey);
}

function showData(fromCache, timestamp, cacheKey) {
  populateFilters();
  applyFilters();
  showState('data');
  $('dateRangeBar').style.display = '';
  $('filtersBar').style.display = '';

  const badge = $('cacheBadge');
  if (fromCache && timestamp) {
    const age = Date.now() - timestamp;
    const ageStr = age < 60000
      ? 'just now'
      : age < 3600000
        ? Math.round(age / 60000) + 'm ago'
        : Math.round(age / 3600000) + 'h ago';
    badge.textContent = '📦 Cached ' + ageStr;
    badge.className = 'badge badge-cache';
  } else {
    badge.textContent = '🟢 Live';
    badge.className = 'badge badge-live';
  }
  badge.style.display = '';
  $('exportBtn').style.display = '';
  $('refreshBtn').style.display = '';

  const ttl = getTTL(activeDays);
  const ttlStr = ttl >= 3600000 ? (ttl/3600000) + 'h' : (ttl/60000) + 'min';
  $('footerLeft').textContent =
    allRecords.length.toLocaleString() + ' records · ' + rangeLabel() +
    ' · Cache: ' + ttlStr;
}

// ─── Range button events ───────────────────────────────────────────────────
document.querySelectorAll('.range-btn').forEach(function(btn) {
  btn.addEventListener('click', async function() {
    setActiveDays(parseInt(btn.dataset.days));
    await fetchAndShow(false);
  });
});

$('customGoBtn').addEventListener('click', async function() {
  const fromVal = $('customFrom').value;
  const toVal = $('customTo').value;
  if (!fromVal || !toVal) return;
  currentFromDate = new Date(fromVal + 'T00:00:00');
  currentToDate = new Date(toVal + 'T23:59:59');
  activeDays = 0;
  document.querySelectorAll('.range-btn').forEach(function(b) { b.classList.remove('active'); });
  await fetchAndShow(false);
});

$('refreshBtn').addEventListener('click', async function() {
  const cacheKey = makeCacheKey(activeDays, currentFromDate, currentToDate);
  await clearCacheEntry(cacheKey);
  await loadFromAPI(cacheKey);
});

// ─── Filters ──────────────────────────────────────────────────────────────
function populateFilters() {
  const sectionSel = $('sectionFilter');
  const userSel = $('userFilter');
  const sectionSet = {}, userSet = {}, sections = [], users = [];
  allRecords.forEach(function(r) {
    if (r.Section && !sectionSet[r.Section]) { sectionSet[r.Section]=1; sections.push(r.Section); }
    const n = r.CreatedBy && r.CreatedBy.Name;
    if (n && !userSet[n]) { userSet[n]=1; users.push(n); }
  });
  sections.sort();
  sectionSel.innerHTML = '<option value="">All Sections</option>';
  sections.forEach(function(s){ const o=document.createElement('option'); o.value=s; o.textContent=s; sectionSel.appendChild(o); });
  users.sort();
  userSel.innerHTML = '<option value="">All Users</option>';
  users.forEach(function(u){ const o=document.createElement('option'); o.value=u; o.textContent=u; userSel.appendChild(o); });
}

function applyFilters() {
  const q = $('searchInput').value.toLowerCase().trim();
  const section = $('sectionFilter').value;
  const user = $('userFilter').value;
  filteredRecords = allRecords.filter(function(r) {
    if (section && r.Section !== section) return false;
    if (user && (!r.CreatedBy || r.CreatedBy.Name !== user)) return false;
    if (q) {
      const hay = [r.Action,r.Section,r.Display,
        r.CreatedBy&&r.CreatedBy.Name, r.CreatedBy&&r.CreatedBy.Username,
        r.DelegateUser].filter(Boolean).join(' ').toLowerCase();
      if (hay.indexOf(q) === -1) return false;
    }
    return true;
  });
  sortAndRender();
}

function sortAndRender() {
  filteredRecords.sort(function(a,b){
    let av = sortCol==='UserName' ? ((a.CreatedBy&&a.CreatedBy.Name)||'') : (a[sortCol]||'');
    let bv = sortCol==='UserName' ? ((b.CreatedBy&&b.CreatedBy.Name)||'') : (b[sortCol]||'');
    if (sortCol==='CreatedDate') { av=new Date(av); bv=new Date(bv); }
    if (av<bv) return sortAsc?-1:1;
    if (av>bv) return sortAsc?1:-1;
    return 0;
  });
  $('filterCount').textContent = filteredRecords.length.toLocaleString()+' of '+allRecords.length.toLocaleString();
  renderTable();
}

function renderTable() {
  const rows = filteredRecords.slice(0, 2000);
  $('tableBody').innerHTML = rows.map(function(r) {
    const date = new Date(r.CreatedDate).toLocaleString(undefined,{month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'});
    const userName  = (r.CreatedBy&&r.CreatedBy.Name)||'—';
    const userLogin = (r.CreatedBy&&r.CreatedBy.Username)||'';
    return '<tr>'+
      '<td title="'+esc(r.CreatedDate)+'">'+date+'</td>'+
      '<td>'+(r.Section?'<span class="section-tag">'+esc(r.Section)+'</span>':'—')+'</td>'+
      '<td title="'+esc(r.Action||'')+'">'+esc(r.Action||'—')+'</td>'+
      '<td>'+esc(userName)+(userLogin?'<br><span style="color:#706e6b;font-size:10px">'+esc(userLogin)+'</span>':'')+'</td>'+
      '<td title="'+esc(r.Display||'')+'">'+esc(r.Display||'—')+'</td>'+
      '<td>'+esc(r.DelegateUser||'—')+'</td>'+
      '</tr>';
  }).join('');
  if (filteredRecords.length>2000) $('filterCount').textContent+=' (showing 2,000)';
}

function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

document.querySelectorAll('th[data-col]').forEach(function(th) {
  th.addEventListener('click', function() {
    const col = th.dataset.col;
    if (sortCol===col) sortAsc=!sortAsc; else { sortCol=col; sortAsc=true; }
    document.querySelectorAll('th[data-col]').forEach(function(t){ t.classList.remove('sorted'); t.querySelector('.sort-icon').textContent=''; });
    th.classList.add('sorted');
    th.querySelector('.sort-icon').textContent = sortAsc?'↑':'↓';
    sortAndRender();
  });
});

$('searchInput').addEventListener('input', applyFilters);
$('sectionFilter').addEventListener('change', applyFilters);
$('userFilter').addEventListener('change', applyFilters);
$('retryBtn').addEventListener('click', init);

$('exportBtn').addEventListener('click', function() {
  const cols = ['CreatedDate','Section','Action','User','Username','Display','DelegateUser'];
  const rows = filteredRecords.map(function(r){
    return [r.CreatedDate,r.Section||'',r.Action||'',
      (r.CreatedBy&&r.CreatedBy.Name)||'',(r.CreatedBy&&r.CreatedBy.Username)||'',
      r.Display||'',r.DelegateUser||''
    ].map(function(v){ return '"'+String(v).replace(/"/g,'""')+'"'; }).join(',');
  });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([[cols.join(',')].concat(rows).join('\n')],{type:'text/csv'}));
  a.download = 'sf_audit_'+toDateStr(currentFromDate)+'_to_'+toDateStr(currentToDate)+'.csv';
  a.click();
});

// ─── Helpers ──────────────────────────────────────────────────────────────
function sleep(ms){ return new Promise(function(r){ setTimeout(r,ms); }); }

function msgTab(tabId, payload) {
  return new Promise(function(resolve) {
    try { chrome.tabs.sendMessage(tabId, payload, function(resp){ if(chrome.runtime.lastError) resolve(null); else resolve(resp); }); }
    catch(e){ resolve(null); }
  });
}

function msgBg(payload) {
  return new Promise(function(resolve, reject) {
    chrome.runtime.sendMessage(payload, function(result){
      if(chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(result);
    });
  });
}

async function bgFetch(url) {
  const result = await msgBg({ type:'BG_FETCH', url:url, sessionId:sessionInfo.sessionId });
  if (!result) throw new Error('No response from background worker');
  if (result.error) throw new Error(result.error);
  if (!result.ok) {
    const d = result.data;
    let sfMsg = 'HTTP '+result.status;
    if (Array.isArray(d) && d[0]&&d[0].message) sfMsg = d[0].errorCode+': '+d[0].message;
    else if (d&&d.message) sfMsg = d.message;
    else if (d&&d._raw) sfMsg = d._raw.slice(0,200);
    if (result.status===401) throw new Error('Session expired. Please refresh your Salesforce tab and click Retry.');
    throw new Error(sfMsg);
  }
  return result.data;
}

function showState(state) {
  $('stateLoading').style.display   = state==='loading'   ? '':'none';
  $('stateNoSession').style.display = state==='noSession' ? '':'none';
  $('stateError').style.display     = state==='error'     ? '':'none';
  $('stateData').style.display      = state==='data'      ? 'flex':'none';
  if (state !== 'data') {
    $('dateRangeBar').style.display = 'none';
    $('filtersBar').style.display = 'none';
  }
}
function showError(m){ $('errorMsg').textContent='⚠ '+m; showState('error'); }
function setMsg(text){ const el=$('loadingMsg'); if(el) el.textContent=text; }
