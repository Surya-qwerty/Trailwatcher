// background.js v11

// ── Open app in a new tab when extension icon is clicked ──────────────────
chrome.action.onClicked.addListener(function() {
  const appUrl = chrome.runtime.getURL('app.html');

  // If tab already open, focus it instead of opening a new one
  chrome.tabs.query({ url: appUrl }, function(existingTabs) {
    if (existingTabs && existingTabs.length > 0) {
      chrome.tabs.update(existingTabs[0].id, { active: true });
      chrome.windows.update(existingTabs[0].windowId, { focused: true });
    } else {
      chrome.tabs.create({ url: appUrl });
    }
  });
});

// ── Session cookie reader ─────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {

  if (msg.type === 'GET_SESSION_BG') {
    const instanceUrl  = msg.instanceUrl;
    const lightningUrl = msg.lightningUrl;

    Promise.all([
      getCookie(instanceUrl,  'sid'),
      getCookie(lightningUrl, 'sid'),
      getCookie(instanceUrl,  'sid_Client'),
      getCookie(lightningUrl, 'sid_Client'),
    ]).then(function(results) {
      const sid = results.find(Boolean);
      sendResponse({ sessionId: sid || null, instanceUrl: instanceUrl });
    });
    return true;
  }

  if (msg.type === 'BG_FETCH') {
    const headers = { 'Content-Type': 'application/json' };
    if (msg.sessionId) headers['Authorization'] = 'Bearer ' + msg.sessionId;

    fetch(msg.url, { headers: headers })
      .then(function(r) {
        const status = r.status, ok = r.ok;
        return r.text().then(function(text) {
          var data;
          try { data = JSON.parse(text); } catch(e) { data = { _raw: text.slice(0, 500) }; }
          sendResponse({ ok: ok, status: status, data: data });
        });
      })
      .catch(function(e) {
        sendResponse({ ok: false, status: 0, error: e.message });
      });
    return true;
  }

});

function getCookie(url, name) {
  return new Promise(function(resolve) {
    try {
      chrome.cookies.get({ url: url, name: name }, function(c) {
        resolve(c ? c.value : null);
      });
    } catch(e) { resolve(null); }
  });
}
