// content.js v22
(function() {
  function toInstanceUrl(host) {
    if (host.match(/\.sandbox\.lightning\.force\.com$/))
      return 'https://'+host.replace('.sandbox.lightning.force.com','.sandbox.my.salesforce.com');
    if (host.match(/\.sandbox\.my\.salesforce-setup\.com$/))
      return 'https://'+host.replace('.sandbox.my.salesforce-setup.com','.sandbox.my.salesforce.com');
    if (host.match(/\.sandbox\.lightning\.salesforce-setup\.com$/))
      return 'https://'+host.replace('.sandbox.lightning.salesforce-setup.com','.sandbox.my.salesforce.com');
    if (host.match(/\.lightning\.force\.com$/))
      return 'https://'+host.replace('.lightning.force.com','.my.salesforce.com');
    if (host.match(/\.lightning\.salesforce-setup\.com$/))
      return 'https://'+host.replace('.lightning.salesforce-setup.com','.my.salesforce.com');
    if (host.match(/\.salesforce-setup\.com$/))
      return 'https://'+host.replace(/\.salesforce-setup\.com$/,'.my.salesforce.com');
    return 'https://'+host;
  }

  chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.type === 'GET_URLS') {
      const host = window.location.hostname;
      sendResponse({
        instanceUrl: toInstanceUrl(host),
        lightningUrl: window.location.origin
      });
    }
    return true;
  });
})();
